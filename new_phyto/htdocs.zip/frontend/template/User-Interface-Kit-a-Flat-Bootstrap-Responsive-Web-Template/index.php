
<!DOCTYPE HTML>
<html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<title>User Interface Ui Kit Flat Bootstrap Responsive Website Template | Home </title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="frontend/public/js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="frontend/public/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }>
</script>
<meta name="keywords" content="User Interface Ui Kit Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!-- start-smoth-scrolling -->
	<script type="text/javascript" src="frontend/public/js/move-top.html"></script>
	<script type="text/javascript" src="frontend/public/js/easing.html"></script>
		<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
						event.preventDefault();
						$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
		</script>
<!--Calender-->
		<link rel="stylesheet" href="css/clndr.css" type="text/css" />
		<script src="frontend/public/js/underscore-min.js"></script>
		<script src= "frontend/public/js/moment-2.2.1.js"></script>
		<script src="frontend/public/js/clndr.js"></script>
		<script src="frontend/public/js/site.js"></script>
  <!--End Calender-->
	</head>
	<body>
<script src='../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script><script>
	(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "../../../../vdo.ai/core/w3layouts/vdo.ai.js");
	</script><!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-125810435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-125810435-1');
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../../../www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>
<body>
		<!--container-->
		<div class="container">
		  <!--main-content-->
		        <h1>User Interface Ui kit</h1>
		  <div class="main-content">
		    <!--top-header-->
				<div class="top-header">
				 <!--top-nav-->
					<div class="col-md-8 top-nav">
					  <span class="menu"> <img src="images/icon.html" alt=""></span>
						<ul class="res">
							<li><a href="#home"><i class="glyphicon glyphicon-user"> </i> Account</a></li>
							<li><a class="active" href="#"><i class="glyphicon glyphicon-cog"> </i> Settings</a></li>
							<li><a href="#"><i class="glyphicon glyphicon-envelope"> </i> Messages <div class="rate">5</div></a></li>
						</ul>
			<!-- script-for-menu -->
						 <script>
						   $( "span.menu" ).click(function() {
							 $( "ul.res" ).slideToggle( 300, function() {
							 // Animation complete.
							  });
							 });
						</script>
						<!-- /script-for-menu -->
				   </div>
				    <div class="col-md-4 serch1">
				    <form>
						<input type="text" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
						<input type="submit" value="">
					</form>
			     </div>
				 <div class="clearfix"> </div>
				<!--top-nav-->
		 </div>
		  <!--top-header-->
		  <!---728x90--->


		   <!--inner-content-->
		    <div class="inner-content">
			  <!--web-forms-->
			    <div class="web-forms">
				 <!--first-one-->
				 <div class="col-md-4 first-one">
				  <div class="first-one-inner">
				     <h3 class="tittle">Sign in</h3>
					<form>
						<input type="text" class="text" value="E-mail address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'E-mail address';}" >
						<input type="password" value="Password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Password';}">
						<div class="submit"><input type="submit" onclick="myFunction()" value="Sign in" ></div>
						<div class="clearfix"></div>
						<div class="new">
							<h3><a href="#">Forgot your password ?</a></h3>
						</div>
					</form>
				   </div>
				   <a href="#" class="hvr-bounce-to-bottom">Sign in with Twitter</a>
			      </div>
				   <!--second-one-->
				 <div class="col-md-4 second-one">
				  <div class="first-one-inner">
				     <h3 class="tittle">EMAIL NEWSLETTER</h3>
					<form>
						<input type="text" class="text" value="E-mail address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'E-mail address';}" >
						<div class="submit"><input type="submit" onclick="myFunction()" value="Sign in" ></div>
						<div class="clearfix"></div>
					</form>
				   </div>
				          <div class="social">
									<div class="col-md-3 social-left ph">
										<div class="img"><img class="img-responsive" src="images/fb.png" alt=""></div><span>100k</span>
									</div>
									<div class="col-md-3 social-left social-middle">
										<div class="img"><img class="img-responsive" src="images/tw.png" alt=""></div><span  class="tw">100k</span>
									</div>
									<div class="col-md-3 social-left social-right">
					  	               <div class="img"><img class="img-responsive" src="images/gmail.png" alt=""></div><span class="gmail">100k</span>
									</div>
									<div class="col-md-3 social-left social-lost">
					  	               <div class="img"><img class="img-responsive" src="images/email.png" alt=""></div><span class="email">100k</span>
									</div>
									<div class="clearfix"></div>
								</div>
			      </div>
				   <!--//second-one-->
				   <!--/third-one-->
				   <div class="col-md-4 first-one">
					    <div class="first-one-inner lost">
						    <div class="here">
								<div class="here-bottom">
									<img src="images/men-1.jpg" alt="">
										<h4>Jonathan Doe</h4>
										<h6>Web Developer</h6>
								</div>
							</div>
					     </div>
						 <div class="deals">
							<div class="sap_tabs">	
									<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
										 <ul class="resp-tabs-list">
											  <li class="resp-tab-item" aria-controls="tab_item-0" role="tab">About me</li>
											  <li class="resp-tab-item" aria-controls="tab_item-1" role="tab">Messages</li>
											   <li class="resp-tab-item resp-tab-active" aria-controls="tab_item-2" role="tab">Add as a Friend</li>
										 </ul>				  	 
										<div class="resp-tabs-container">
											<h2 class="resp-accordion" role="tab" aria-controls="tab_item-0">
											<span class="resp-arrow"></span>TAB DATAPOPULARConnexionConnexion</h2>
												<h2 class="resp-accordion" role="tab" aria-controls="tab_item-1"><span class="resp-arrow"></span>RECENTS'inscrireS'inscrire</h2><h2 class="resp-accordion resp-tab-active" role="tab" aria-controls="tab_item-2"><span class="resp-arrow"></span>Mot de passeMot de passe</h2><h2 class="resp-accordion" role="tab" aria-controls="tab_item-3"><span class="resp-arrow"></span></h2><div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
													<p>Ut wisi enim ad minim veniam,nostrud exerci tation ullamcorpersuscipit lobortis nisl ut aliquip ex eacommodo consequat. Claritas est etiamprocessus dynamicus, qui sequitur.</p>
												</div>
												<h2 class="resp-accordion" role="tab" aria-controls="">
												<span class="resp-arrow"></span>TAB DATA</h2>
												<h2 class="resp-accordion" role="tab" aria-controls="tab_item-5"><span class="resp-arrow"></span></h2><h2 class="resp-accordion" role="tab" aria-controls="tab_item-6"><span class="resp-arrow"></span></h2><div class="tab-1 resp-tab-content" aria-labelledby="tab_item-1">
													<p>he printing and typesetting industry.Lorem Ut wisi enim ad minim veniam,nostrud exerci tation ullamcorpersuscipit lobortis nisl ut aliquip ex eacommodo consequat. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
												</div>										
										</div>
									</div>
									<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
									<script type="text/javascript">
										$(document).ready(function () {
											$('#horizontalTab').easyResponsiveTabs({
												type: 'default', //Types: default, vertical, accordion           
												width: 'auto', //auto or any width like 600px
												fit: true   // 100% fit in a container
											});
										});
									   </script>	
							</div>				
				         </div>
				      </div>
					  	<div class="clearfix"></div>
				   <!--//third-one-->
			    </div>
				  <!--//web-forms-->
				  <!---728x90--->


				  <!--skills-->
				   <div class="main-skills">
				     <!--skill-one-->
						 <div class="col-md-4 skill-one">
							 <div class="skill-inner">
								<h3 class="tittle">My Skills</h3>
								<div class="skills-top">
									<h5>CSS</h5>
									<div class="skills">
										<div class="skill1" style="width:55%"></div>
									</div>
								</div>
								<div class="skills-top">
									<h5>HTML</h5>
									<div class="skills">
										<div class="skill1" style="width:90%"></div>
									</div>
								</div>
								<div class="skills-top">
									<h5>PHOTOSHOP</h5>
									<div class="skills">
										<div class="skill1" style="width:80%"></div>
									</div>
						     </div>			
							<div class="skills-top lost">
									<h5>PHP</h5>
									<div class="skills">
										<div class="skill1" style="width:60%"></div>
									</div>
						     </div>			
                               <a href="#" class="hvr-bounce-to-bottom2">Download my resume</a>							 
							 </div>
						 </div>
						  <!--//skill-one-->
						   <!--menu-->
						    <div class="col-md-4 skill-one">
							    <div class="mid-menu">
								   <span class="menu2"><lable> MENU</lable></span>
								   <ul class="effct1" style="display: block;">
									<li><a href="#">Messages<span>30</span></a></li>                                             
									<li><a href="#">Invite<span>05</span></a></li>
									<li><a href="#">Events<span>10</span></a></li>  
									<li><a href="#">Account Settings</a></li>  
									<li><a href="#">Folder</a></li> 
									<li class="lost"><a href="#">Statistics</a></li>
								  </ul>
								</div>
							</div>
						     <!--//menu-->
							   <!--twitter-->
							 <div class="col-md-4 skill-one">
							    <div class="twitter">
								   <span class="twitter"><img class="img-responsive" src="images/tw.png" alt=""><lable>Latest Tweet</lable></span>
								   <div class="t-inner">
								     <div class="t-first">
										 <p>Ut wisi enim ad minim veniam, quisnostrud exerci tation ullamcorpersuscipit lobortis nisl ut aliquip ex eacommodo consequat. . . <a href="#">@ Admin</a> </p>
										 <span>2 days ago</span>
									 </div>
									 <div class="t-first two">
										 <p>Ut wisi enim ad minim veniam, quisnostrud exerci tation ullamcorpersuscipit lobortis nisl ut aliquip ex eacommodo consequat. . . <a href="#">@ Admin</a> </p>
										 <span>2 days ago</span>
									 </div>
								   </div>
								</div>
							</div>
						 <div class="clearfix"></div>
						   
				   </div>
				  <!--skills-->
				    <!--/accordions-->
					  <div class="mid-tabs-top">
				           <!--skill-one-->
						 <div class="col-md-6 mid-tabs">
						 <div id="tabs" class="tabs">
								<nav>
									<ul>
										<li><a href="#section-1"><i class="glyphicon glyphicon-picture"></i> <span> Images</span></a></li>
										<li><a href="#section-2"><i class="glyphicon glyphicon-facetime-video"></i> <span> Video</span></a></li>
										<li><a href="#section-3"><i class="glyphicon glyphicon-file"></i> <span> Post</span></a></li>
									</ul>
								</nav>
									<div class="content">
										<section id="section-1">
											<div class="tab-inner">
												<div class="tab-grids">
													<div class="tab-img">
														<img class="img-responsive" src="images/pic.jpg" alt="">
															<h4>Image 01</h4>	 
													 </div>
													<div class="tab-img">
														<img class="img-responsive" src="images/pic1.jpg" alt="">
																<h4>Image 01</h4>	 
													</div>
										            <div class="tab-img">
														<img class="img-responsive" src="images/pic2.jpg" alt="">
															<h4>Image 01</h4>	 
																	 
												     </div>
														<div class="clearfix"></div>
												</div>
												<div class="clearfix"></div>
											</div>
										</section>
										<section id="section-2">
											<div class="tab-inner">
												<iframe src="https://player.vimeo.com/video/25025844"></iframe>
											</div>
										</section>
										<section id="section-3">
											<div class="tab-inner">
											   <img class="img-responsive" src="images/post.jpg" alt="">
											 </div>
										</section>
									</div><!-- /content -->
								</div><!-- /tabs -->
						<link rel="stylesheet" type="text/css" href="css/component.css" />
					</div>
						<script src="js/cbpFWTabs.js"></script>
						<script>
							new CBPFWTabs( document.getElementById( 'tabs' ) );
							</script>
						  
				</div>
						  <div class="col-md-6 accordions">
						    <section class="ac-container">
									<div>
										<input id="ac-1" name="accordion-1" type="checkbox" />
										<label for="ac-1">MENU ONE</label>
										<article class="ac-small">
											<p>Well, the way they make shows is, they make one show. That show's called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they're going to make more shows.</p>
										</article>
									</div>
									<div>
										<input id="ac-2" name="accordion-1" type="checkbox" />
										<label for="ac-2">MENU TWO</label>
										<article class="ac-medium">
											<p>Like you, I used to think the world was this great place where everybody lived by the same standards I did, then some kid with a nail showed me I was living in his world, a world where chaos rules not order, a world where righteousness is not rewarded. That's Cesar's world, and if you're not willing to play by his rules, then you're gonna have to pay the price. </p>
										</article>
									</div>
									<div>
										<input id="ac-3" name="accordion-1" type="checkbox" />
										<label for="ac-3">MENU THREE</label>
										<article class="ac-large">
											<p>You think water moves fast? You should see ice. It moves like it has a mind. Like it knows it killed the world once and got a taste for murder. After the avalanche, it took us a week to climb out. Now, I don't know exactly when we turned on each other, but I know that seven of us survived the slide... and only five made it out. Now we took an oath, that I'm breaking now. We said we'd say it was the snow that killed the other two, but it wasn't. Nature is lethal but it doesn't hold a candle to man. </p>
										</article>
									</div>
									<div>
										<input id="ac-4" name="accordion-1" type="checkbox" />
										<label for="ac-4">MENU FOUR</label>
										<article class="ac-large">
											<p>You see? It's curious. Ted did figure it out - time travel. And when we get back, we gonna tell everyone. How it's possible, how it's done, what the dangers are. But then why fifty years in the future when the spacecraft encounters a black hole does the computer call it an 'unknown entry event'? Why don't they know? If they don't know, that means we never told anyone. And if we never told anyone it means we never made it back. Hence we die down here. Just as a matter of deductive logic. </p>
										</article>
									</div>
								</section>


						   </div>
						  <div class="clearfix"></div>
					    </div>
						<div class="clearfix"> </div>
					  <!--//accordions-->
					    <!--/pricing-tables-->
						<div class="pricing-grids">
							<div class="col-md-3 pricing-grid">
								<div class="price-value">
									<h3>Economy</h3>
									<p class="price-label-1">$<span>12</span></p>
									<a class="month" href="#">Monthly</a>
									<div class="box">
										<div class="ribbon"><span>Popular</span></div>
									</div>
								</div>
							<div class="price-bg">							
								<ul class="count">
								    <li><p>2GB</p>Trafic</li>
									<li><p>200MB</p>Disk Space</li>
									<li><p class="red">UNLIMITED </p>Subdomain</li>
									<li><i class="glyphicon glyphicon-ok"></i> Advanced Options</li>
									<li><i class="glyphicon glyphicon-remove"></i> 200GB Storage</li>
									<li><i class="glyphicon glyphicon-ok"></i> 3GB BandWidth</li>
								</ul>
									<p class="bottom"><a href="#">SIGN IN</a></p>
							</div>
						</div>
					<div class="col-md-3 pricing-grid">
					<div class="price-value">
						<h3>Personal</h3>
						<p class="price-label-1">$<span>12</span></p>
								<a class="month" href="#">Monthly</a>
								<div class="box">
										<div class="ribbon"><span>Popular</span></div>
									</div>
					</div>
							<div class="price-bg">							
								<ul class="count">
								    <li><p>2GB</p>Trafic</li>
									<li><p>200MB</p>Disk Space</li>
									<li><p class="red">UNLIMITED </p>Subdomain</li>
									<li><i class="glyphicon glyphicon-ok"></i> Advanced Options</li>
									<li><i class="glyphicon glyphicon-remove"></i> 200GB Storage</li>
									<li><i class="glyphicon glyphicon-ok"></i> 3GB BandWidth</li>
								</ul>
									<p class="bottom"><a href="#">SIGN IN</a></p>
							</div>
						</div>
				<div class="col-md-3 pricing-grid">
								<div class="price-value">
									<h3>Business</h3>
									<p class="price-label-1">$<span>12</span></p>
								     <a class="month" href="#">Monthly</a>
									 <div class="box">
										<div class="ribbon"><span>Popular</span></div>
									</div>
								</div>
								
										<div class="price-bg">							
											<ul class="count">
											    <li><p>2GB</p>Trafic</li>
									            <li><p>200MB</p>Disk Space</li>
												<li><p class="red">UNLIMITED </p>Subdomain</li>
												<li><i class="glyphicon glyphicon-ok"></i> Advanced Options</li>
												<li><i class="glyphicon glyphicon-remove"></i> 200GB Storage</li>
												<li><i class="glyphicon glyphicon-ok"></i> 3GB BandWidth</li>
											</ul>
												<p class="bottom"><a href="#">SIGN IN</a></p>
										</div>
									</div>
								<div class="col-md-3 pricing-grid">
									<div class="price-value">
										<h3>Enterprise</h3>
										<p class="price-label-1">$<span>12</span></p>
											<a class="month" href="#">Monthly</a>
											<div class="box">
										<div class="ribbon"><span>Popular</span></div>
									</div>
									</div>
											<div class="price-bg">							
												<ul class="count">
												    <li><p>2GB</p>Trafic</li>
									                <li><p>200MB</p>Disk Space</li>
													<li><p class="red">UNLIMITED </p>Subdomain</li>
													<li><i class="glyphicon glyphicon-ok"></i> Advanced Options</li>
													<li><i class="glyphicon glyphicon-remove"></i> 200GB Storage</li>
													<li><i class="glyphicon glyphicon-ok"></i> 3GB BandWidth</li>
												</ul>
													<p class="bottom"><a href="#">SIGN IN</a></p>
											</div>
										</div>
						
									<div class="clearfix"> </div>
								</div>
						  <!--//pricing-tables-->
						  <!--/cal-grids-->
						    <!--/call-inner-->
							  <div class="cal-grids">
							     <div class="col-md-4 call-inner">
										 <div class="skill-inner">
										<h3 class="tittle dow">DOWNLOAD & UPLOAD</h3>
										 <div class="upload"> <a href="#"><img class="img-responsive" src="images/upload-one.png" alt=""></a> </div>
										<div class="skills-top">
										     <div class="skills two">
												<div class="skill1 second" style="width:81%"></div>
											</div>
											<ul class="down">
											  <li> <img class="img-responsive" src="images/down.png" alt="">  </li>
										      <li> <h5 class="down">Downloading...</h5>  </li>
											  <li> <h6 >81%</h6>  </li>
											 </ul>
										</div>
										<div class="skills-top">
											<div class="skills two">
												<div class="skill1 second" style="width:43%"></div>
											</div>
											<ul class="down">
											  <li> <img class="img-responsive" src="images/upload.png" alt="">  </li>
										      <li> <h5 class="down">Uploading...</h5>  </li>
											  <li> <h6 >43%</h6>  </li>
											 </ul>
										</div>						 
									 </div>
								 </div>
								 <div class="col-md-4 call-inner">
								   <div class="calender">
									  <div class="cal1"><div class="clndr"><div class="clndr-controls"><div class="clndr-control-button"><p class="clndr-previous-button">previous</p></div><div class="month">September 2014</div><div class="clndr-control-button rightalign"><p class="clndr-next-button">next</p></div></div><table class="clndr-table" border="0" cellspacing="0" cellpadding="0"><thead><tr class="header-days"><td class="header-day">S</td><td class="header-day">M</td><td class="header-day">T</td><td class="header-day">W</td><td class="header-day">T</td><td class="header-day">F</td><td class="header-day">S</td></tr></thead><tbody><tr><td class="day past adjacent-month last-month calendar-day-2014-08-31"><div class="day-contents">31</div></td><td class="day past calendar-day-2014-09-01"><div class="day-contents">1</div></td><td class="day past calendar-day-2014-09-02"><div class="day-contents">2</div></td><td class="day past calendar-day-2014-09-03"><div class="day-contents">3</div></td><td class="day past calendar-day-2014-09-04"><div class="day-contents">4</div></td><td class="day past calendar-day-2014-09-05"><div class="day-contents">5</div></td><td class="day past calendar-day-2014-09-06"><div class="day-contents">6</div></td></tr><tr><td class="day past calendar-day-2014-09-07"><div class="day-contents">7</div></td><td class="day past calendar-day-2014-09-08"><div class="day-contents">8</div></td><td class="day past calendar-day-2014-09-09"><div class="day-contents">9</div></td><td class="day past calendar-day-2014-09-10"><div class="day-contents">10</div></td><td class="day past calendar-day-2014-09-11"><div class="day-contents">11</div></td><td class="day past calendar-day-2014-09-12"><div class="day-contents">12</div></td><td class="day past calendar-day-2014-09-13"><div class="day-contents">13</div></td></tr><tr><td class="day past calendar-day-2014-09-14"><div class="day-contents">14</div></td><td class="day past calendar-day-2014-09-15"><div class="day-contents">15</div></td><td class="day past calendar-day-2014-09-16"><div class="day-contents">16</div></td><td class="day past calendar-day-2014-09-17"><div class="day-contents">17</div></td><td class="day past calendar-day-2014-09-18"><div class="day-contents">18</div></td><td class="day past calendar-day-2014-09-19"><div class="day-contents">19</div></td><td class="day past calendar-day-2014-09-20"><div class="day-contents">20</div></td></tr><tr><td class="day past calendar-day-2014-09-21"><div class="day-contents">21</div></td><td class="day past calendar-day-2014-09-22"><div class="day-contents">22</div></td><td class="day past calendar-day-2014-09-23"><div class="day-contents">23</div></td><td class="day past calendar-day-2014-09-24"><div class="day-contents">24</div></td><td class="day past calendar-day-2014-09-25"><div class="day-contents">25</div></td><td class="day past calendar-day-2014-09-26"><div class="day-contents">26</div></td><td class="day past calendar-day-2014-09-27"><div class="day-contents">27</div></td></tr><tr><td class="day past calendar-day-2014-09-28"><div class="day-contents">28</div></td><td class="day past calendar-day-2014-09-29"><div class="day-contents">29</div></td><td class="day past calendar-day-2014-09-30"><div class="day-contents">30</div></td><td class="day past adjacent-month next-month calendar-day-2014-10-01"><div class="day-contents">1</div></td><td class="day past adjacent-month next-month calendar-day-2014-10-02"><div class="day-contents">2</div></td><td class="day past adjacent-month next-month calendar-day-2014-10-03"><div class="day-contents">3</div></td><td class="day past adjacent-month next-month calendar-day-2014-10-04"><div class="day-contents">4</div></td></tr></tbody></table></div></div>
								   </div>
								 </div>
								 <div class="col-md-4 buttons">
								    <div class="sub-buttons">
									    <a href="#" class="hvr-sweep-to-right button">Button</a>
										<a href="#" class="hvr-rectangle-out button">Button</a>
									</div>
									  <div class="sub-buttons">
									    <a href="#" class="hvr-shutter-out-vertical button">Button</a>
										<a href="#" class="hvr-radial-out button">Button</a>
									</div>
									<div class="sub-buttons">
									     <a href="#" class="hvr-bounce-to-right button">Button</a>
									    <a href="#" class="hvr-bounce-to-left button">Button</a>
									</div>
									<div class="sub-buttons">
										<a href="#" class="hvr-hollow button2">Button</a>
									   <a href="#" class="hvr-trim button2">Button</a>
									</div>
									<div class="sub-buttons">
									     <a href="#" class="hvr-bounce-to-right button">Button</a>
									    <a href="#" class="hvr-bounce-to-left button">Button</a>
									</div>
								 </div>
							 	<div class="clearfix"> </div>
								  <!--//call-inner-->
								</div>
							</div>
						  <!--/cal-grids-->
			     </div>
				<!--main-content-->
				<!--start-copyright-->
						  <!---728x90--->


				<div class="copy-right">
						<p><a target="_blank" href="https://www.templateshub.net">Templates Hub</a></p>
				</div>
	<!--//end-copyright-->

		</div>
	 <!--//container-->
	</body>

</html>

