<?php $title = 'POSTE PHYTOSANITAIRE DE L\'AEROPORT INTERNATIONAL DE DOUALA' ?>

<?php ob_start() ?>
<br><br>
<div class="container" style="background:white; padding:2%; text-align:left;">
    <h2><b>POSTE PHYTOSANITAIRE DE L'AEROPORT INTERNATIONAL DE DOUALA</b></h2>
    <div>
       
    </div>
</div>


<br><br><br><br><br>
<br><br><br><br><br>
<?php $content = ob_get_clean() ?>

<?php 
    require 'frontend/template/tmp/u.php';
?>