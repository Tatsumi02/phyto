<?php $title = 'Phyto admin' ?>

<?php ob_start() ?>
<br><br>
<div class="container">
<br><br>
    <div class="alert alert-warning"><h1>PHYTO ADMIN ACOUNT</h1></div>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php $content = ob_get_clean() ?>

<?php 
    require 'frontend/template/tmp/a.php';
?>